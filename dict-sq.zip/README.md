# hyph-sq-al
Hunspell compatible hyphenator for Albanian
